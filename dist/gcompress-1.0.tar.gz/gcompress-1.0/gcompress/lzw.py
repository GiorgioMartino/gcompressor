#!/usr/bin/env python3
# -*- coding: utf-8 -*-

def compress(fn):
    print("\nComprimo")

def decompress(fn):
    print("\nDecomprimo")
